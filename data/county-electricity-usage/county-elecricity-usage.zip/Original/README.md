Data sourced from <https://www.eia.gov/electricity/data/eia861/>
